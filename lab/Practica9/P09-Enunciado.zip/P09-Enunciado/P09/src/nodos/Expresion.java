package nodos;

public interface Expresion extends Nodo {
    
}
