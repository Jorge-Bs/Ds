package nodos;

public class Variable implements Expresion {
	public String name;

	public Variable(String name) {
		this.name = name;
	}
}
