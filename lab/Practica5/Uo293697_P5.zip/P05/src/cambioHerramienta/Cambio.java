package cambioHerramienta;

public interface Cambio {

    public void undo();

    public void redo();
}
