package editor.core.figuras;

public interface Figuras {

    public void dibujar();

    public void mover();

    public boolean contienePunto(Vertice vertice);
}
