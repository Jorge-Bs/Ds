package editor.core;

public class Dibujo {
    /*
    public addFigura(...) {
    	// TO DO
    }
    */

    public void dibujar() {
        // Dibujar las figuras que contenga
    }
}
