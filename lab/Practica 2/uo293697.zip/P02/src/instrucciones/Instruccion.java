package instrucciones;

import machine.Wrapper;

public interface Instruccion {

	public void operar(Wrapper wrap);
}
