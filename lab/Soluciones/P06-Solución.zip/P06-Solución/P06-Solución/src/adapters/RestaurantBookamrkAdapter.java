package adapters;

import google.maps.*;
import model.*;


public class RestaurantBookamrkAdapter implements BookMark {

	private Restaurant restaurante;
	private Navigator navegador = new Navigator();

	public RestaurantBookamrkAdapter(Restaurant restaurante) {
		this.restaurante = restaurante;
	}

	@Override
	public Coordinates getCoordinates() {
		return navegador.getCoordinates(restaurante.getAddress());
	}

	@Override
	public String getTooltipInfo() {
		return "Restaurante '" + restaurante.getName() + "'. Tfn: " + restaurante.getPhone();
	}

	@Override
	public void open() {
		restaurante.call();
	}

}
