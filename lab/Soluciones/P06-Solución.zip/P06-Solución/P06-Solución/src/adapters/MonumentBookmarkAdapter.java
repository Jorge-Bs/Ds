package adapters;

import google.maps.*;
import model.*;

public class MonumentBookmarkAdapter implements BookMark {

	private Monument monumento;
	private Navigator navegador = new Navigator();

	public MonumentBookmarkAdapter(Monument monument) {
		this.monumento = monument;
	}

	@Override
	public Coordinates getCoordinates() {
		return navegador.getCoordinates(monumento.getAddress());
	}

	@Override
	public String getTooltipInfo() {
		return monumento.getName() + ". Construido por " + monumento.getAuthor();
	}

	@Override
	public void open() {
		navegador.navigateTo(monumento.getAddress());
	}

}
