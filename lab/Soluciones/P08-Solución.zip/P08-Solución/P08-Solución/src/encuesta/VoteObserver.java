package encuesta;

public interface VoteObserver {
	void votoRecibido(Pregunta encuesta);
}
