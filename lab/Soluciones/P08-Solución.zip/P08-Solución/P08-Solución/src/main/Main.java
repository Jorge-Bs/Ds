package main;
import java.io.*;

import observers.*;
import encuesta.*;

public class Main {
	static GraficoDeBarras gb = new GraficoDeBarras();
	static GraficoCircular gc = new GraficoCircular();
	static Backup bu = new Backup();
	static LineaDeEstado lde = new LineaDeEstado();
	static Activador a3vgc = new Activador(3, gc);	// El gráfico circular sólo se dibuja a partir del tercer voto
	static Repetidor r3vgb = new Repetidor(3, gb); // El gráfico de barras se dibujará cada 3 votos (con el primero, cuarto, séptimo, etc.).

	public static void main(String[] args) throws IOException {
		Pregunta encuesta = new Pregunta("¿Está a favor de la energia nuclear?");

		Programa0(encuesta);
//		Programa1(encuesta);
//		Programa2(encuesta);
//		Programa3(encuesta);
//		Programa4(encuesta);
//		Programa5(encuesta);
	
		// -------------------------------------------------------
		// Inicio del cuestionario
		TextUserInterface userInterface = new TextUserInterface();
		userInterface.rellena(encuesta);
	}

	/**
	 * Programa 0. Detectar los puntos de mejora en el diseño. Rediseñarlo usando uno o más patrones.
	 * A partir de este punto no debería tener que modificarse la clase Pregunta para realizar
	 * el resto de las modificaciones.
	 * 
	 * @param encuesta Es la pregunta
	 */
	private static void Programa0(Pregunta encuesta) {
		encuesta.addObserver(gb);
		encuesta.addObserver(gc);
		encuesta.addObserver(bu);
	}
	
	/**
	 * Programa 1. Hacer una nueva versión del programa que al recibir 
	 * un voto también se dibuje una línea de estado.
	 * Una línea de estado es una línea de texto que indica el estado 
	 * actual de la votación (nº de votos SI = <x>. nº de votos NO = <y>).
	 * 
	 * @param encuesta Es la pregunta
	 */
	private static void Programa1(Pregunta encuesta) {

//		encuesta.addObserver(gb);
//		encuesta.addObserver(gc);
//		encuesta.addObserver(bu);
		encuesta.addObserver(lde);	// Añadida al caso anterior
	}

	/**
	 * Programa 2. Que no dibuje el gráfico de barras.
	 * 
	 * @param encuesta Es la pregunta
	 */
	private static void Programa2(Pregunta encuesta) {
// 		encuesta.addObserver(gb); // Sólo habría que eliminar este observer
		encuesta.removeObserver(gb);
//		encuesta.addObserver(gc);
//		encuesta.addObserver(bu);
//		encuesta.addObserver(lde);
	}
	
	/**
	 * Programa 3. Hacer otra versión del programa que, en vez de dibujarlo 
	 * con cada voto, el gráfico circular sólo se dibuja a partir del tercer 
	 * voto (y a partir de ahí con cada voto).
	 * 
	 * @param encuesta Es la pregunta
	 */
	private static void Programa3(Pregunta encuesta) {
		encuesta.removeObserver(gc);
		encuesta.addObserver(a3vgc);
//		encuesta.addObserver(bu);
//		encuesta.addObserver(lde);
	}
	
	/**
	 * Programa 4. Hacer otra versión del programa en la que vuelva a estar 
	 * el gráfico de barras, pero ahora sólo se dibujará cada 3 votos
	 * (con el primero, cuarto, séptimo, etc.).
	 * 
	 * @param encuesta Es la pregunta
	 */
	private static void Programa4(Pregunta encuesta) {
//		encuesta.addObserver(a3vgc);
//		encuesta.addObserver(bu);
//		encuesta.addObserver(lde);
		encuesta.addObserver(r3vgb);
	}
	
	/**
	 * Programa 5. Hacer una última versión del programa en la que la línea 
	 * de estado debe comenzar a imprimirse a partir del cuarto voto y 
	 * a partir de ahí se imprimará cada dos
	 * (se imprimirá en el cuarto, sexto, octavo, etc.).
	 * 
	 * @param encuesta Es la pregunta
	 */
	private static void Programa5(Pregunta encuesta) {
//		encuesta.addObserver(r3vgb);
//		encuesta.addObserver(a3vgc);
//		encuesta.addObserver(bu);
		encuesta.removeObserver(lde);
		encuesta.addObserver(new Activador(4, new Repetidor(2, lde)));
	}
	
}
