package observers;

import encuesta.*;

public class Backup implements VoteObserver {

	@Override
	public void votoRecibido(Pregunta encuesta) {
		int gvs=encuesta.getVotosSi();
		int gvn=encuesta.getVotosNo();
		
		StringBuilder graph = new StringBuilder();
		graph.append("BACKUP: Guardando resultados:\n");
		graph.append("\tSi = " + gvs +  "\n");
		graph.append("\tNo = " + gvn +  "\n");
		graph.append("FIN BACKUP");
		System.out.println(graph);
	}

}
