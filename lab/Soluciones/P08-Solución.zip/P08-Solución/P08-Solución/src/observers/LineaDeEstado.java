package observers;

import encuesta.*;

public class LineaDeEstado implements VoteObserver {

	@Override
	public void votoRecibido(Pregunta encuesta) {
		StringBuilder graph = new StringBuilder();
		graph.append("LINEA DE ESTADO: Votos recibidos: ");
		graph.append("[Si = " + encuesta.getVotosSi() + "]");
		graph.append(" [No = " + encuesta.getVotosNo() + "]");
		System.out.println(graph);
	}

}
