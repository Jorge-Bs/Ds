package observers;

import encuesta.*;

public class GraficoDeBarras implements VoteObserver {

	@Override
	public void votoRecibido(Pregunta encuesta) {
		int gvs=encuesta.getVotosSi();
		int gvn=encuesta.getVotosNo();
		
		StringBuilder graph = new StringBuilder();
		graph.append("Dibujando gráfico de barras\n");
		
		graph.append("\tSI: ");
		while (gvs > 0){
			graph.append("X");
			gvs--;
		}
		graph.append("\n\tNO: ");
		while (gvn > 0){
			graph.append("X");
			gvn--;
		}
		graph.append("\nFin gráfico de barras");
		System.out.println(graph);
	}

}
