package observers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import encuesta.*;

public class LineaDeEstado implements VoteObserver {

	@Override
	public void votoRecibido(Pregunta encuesta) {
		Iterator<String> ops = encuesta.getOpciones();
		
		StringBuilder graph = new StringBuilder();
		graph.append("LINEA DE ESTADO: Votos recibidos: ");
		
		while (ops.hasNext()) {
			String o = ops.next();
			int nv = encuesta.getVotos(o);
			graph.append("[" + o + " = " + nv +  "] ");
		}
		System.out.println(graph);	
	}

}
