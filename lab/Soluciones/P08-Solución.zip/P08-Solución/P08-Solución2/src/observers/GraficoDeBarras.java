package observers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import encuesta.*;

public class GraficoDeBarras implements VoteObserver {

	@Override
	public void votoRecibido(Pregunta encuesta) {
		Iterator<String> ops = encuesta.getOpciones();
		
		StringBuilder graph = new StringBuilder();
		graph.append("Dibujando gráfico de barras\n");
		
		while (ops.hasNext()) {
			String o = ops.next();
			int nv = encuesta.getVotos(o);
			graph.append("\t" + o + ": ");
			for (int i = 0; i < nv; i++)
				graph.append("X");
			graph.append("\n");
		}

		graph.append("Fin gráfico de barras");
		System.out.println(graph);	
		}

}
