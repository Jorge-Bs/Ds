package observers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import encuesta.*;

public class Backup implements VoteObserver {

	@Override
	public void votoRecibido(Pregunta encuesta) {
		Iterator<String> ops = encuesta.getOpciones();
		
		StringBuilder graph = new StringBuilder();
		graph.append("BACKUP: Guardando resultados:\n");
		
		while (ops.hasNext()) {
			String o = ops.next();
			int nv = encuesta.getVotos(o);
			graph.append("\t" + o + " = " + nv +  "\n");
		}
		graph.append("FIN BACKUP");
		System.out.println(graph);
	}

}
