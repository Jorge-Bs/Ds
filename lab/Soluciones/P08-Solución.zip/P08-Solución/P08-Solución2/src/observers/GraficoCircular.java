package observers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import encuesta.*;

public class GraficoCircular implements VoteObserver {

	@Override
	public void votoRecibido(Pregunta encuesta) {
		Iterator<String> ops = encuesta.getOpciones();
		
		int totv = encuesta.getTotVotos();
		
		StringBuilder graph = new StringBuilder();
		graph.append("Dibujando gráfico circular-->");
		
		while (ops.hasNext()) {
			String o;
			double vsdegree=(encuesta.getVotos(o = ops.next())/((double) totv))*360.0;
			graph.append(" " + o + ": " + vsdegree);
		}

		System.out.println(graph);
	}

}
