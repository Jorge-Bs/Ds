package encuesta;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class TextUserInterface {

	public void rellena(Pregunta encuesta) throws IOException {

		in = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Opciones:");
		List<String> opciones = new ArrayList<>();
		Iterator<String> ops = encuesta.getOpciones();
		while (ops.hasNext()) {
			opciones.add(ops.next());
		}

		opciones.forEach(s -> System.out.print(s + " "));
		System.out.println("\nexit (para terminar)");

		do {
			System.out.println("\nPregunta: " + encuesta.getPregunta());
			System.out.print(">");

			String[] line = in.readLine().split(" ");
			// No se comprueba que el número de palabras sea el adecuado

			if (line[0].equals("exit"))
				return;

			if (opciones.contains(line[0]))
				encuesta.incrementaVoto(line[0]);
			else
				System.out.print("Opción errónea");

		} while (true);

	}

	private static BufferedReader in;
}

