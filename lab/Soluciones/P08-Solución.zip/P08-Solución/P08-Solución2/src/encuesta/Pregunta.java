package encuesta;

import java.util.*;

public class Pregunta {

	public Pregunta(String pregunta, String...strings) {
		this.pregunta = pregunta;
		for (String s : strings)
			votos.put(s, 0);
	}

	public String getPregunta() {
		return pregunta;
	}

	public int getVotos (String s) {
		if (votos.containsKey(s))
			return votos.get(s);
		return -1;
	}
	
	public void incrementaVoto(String s) {
		if (votos.containsKey(s))
			votos.put(s, votos.get(s) + 1);
		totVotos++;
		avisaObservers();
	}

	public int getTotVotos() {
		return totVotos;
	}

	public void addObserver(VoteObserver observer) {
		observers.add(observer);
	}

	public void removeObserver(VoteObserver observer) {
		observers.remove(observer);
	}
	
	public Iterator<String> getOpciones() {
		return votos.keySet().iterator();
	}

	private void avisaObservers() {
		for (VoteObserver voteObserver : observers)
			voteObserver.votoRecibido(this);
	}

	private int totVotos = 0;
	private Map<String,Integer> votos = new HashMap<>();
	private String pregunta;
	private List<VoteObserver> observers = new ArrayList<>();
}
