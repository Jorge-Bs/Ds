package editor.core;

public interface Cambio {
	void undo();
	void redo();
}
