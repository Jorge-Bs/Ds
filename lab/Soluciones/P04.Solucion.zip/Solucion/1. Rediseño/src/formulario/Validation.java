package formulario;
public interface Validation {
	public boolean isValid(String texto);
}
