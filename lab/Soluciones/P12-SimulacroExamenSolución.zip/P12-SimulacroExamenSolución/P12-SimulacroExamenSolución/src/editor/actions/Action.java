package editor.actions;

import editor.Editor;

public interface Action 
{
	void execute(Editor editor);
}
