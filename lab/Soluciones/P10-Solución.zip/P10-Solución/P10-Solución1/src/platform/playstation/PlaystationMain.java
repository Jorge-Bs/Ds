package platform.playstation;

public class PlaystationMain {

	public static void main(String[] args) {
		PlaystationBallGame game = new PlaystationBallGame();
		game.play();
	}

}
