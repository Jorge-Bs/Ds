package platform.windows;

public class WindowsMain {

	public static void main(String[] args) {
		WindowsBallGame game = new WindowsBallGame();
		game.play();
	}

}
