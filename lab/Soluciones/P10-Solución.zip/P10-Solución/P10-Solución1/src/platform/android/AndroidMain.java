package platform.android;

public class AndroidMain {

	public static void main(String[] args) {
		AndroidBallGame game = new AndroidBallGame();
		game.play();
	}

}
