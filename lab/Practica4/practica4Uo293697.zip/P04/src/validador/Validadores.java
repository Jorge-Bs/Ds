package validador;

public interface Validadores {

    public boolean isValido(String word);
}
