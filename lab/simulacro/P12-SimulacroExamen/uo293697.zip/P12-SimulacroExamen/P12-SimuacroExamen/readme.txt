Patron command

Cliente -> el editor

Command -> define la interfaz( interfaz Accion)

ConcreteCommand -> cada una de las implementaciones (Borrar, Insertar, Reemplazar, Grabador)

Receiver -> el editor

Patron Composite

Cliente -> el editor

Componente -> objetos del patron anterior

Composite -> clase Grabador, posee una lista de acción