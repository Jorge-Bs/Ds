package acciones;

public interface Accion {

    public StringBuilder ejecutar(StringBuilder texto);
}
