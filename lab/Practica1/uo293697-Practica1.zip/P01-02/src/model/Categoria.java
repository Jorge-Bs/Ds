package model;

public interface Categoria {
	public double getPrecio(Rental rental);
	
	public int getPoints(Rental rental);
}
